package com.example.mytask

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.example.mytask.data.TaskDatabase
import com.example.mytask.navigation.NavGraph
import com.example.mytask.repository.TaskRepository
import com.example.mytask.viewmodel.TaskViewModel
import com.example.mytask.viewmodel.TaskViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MyTasksApp()
        }
    }

    @Composable
    fun MyTasksApp() {
        // 1. Access DAO and Repository
        val dao = TaskDatabase.getDatabase(applicationContext).taskDao()
        val repository = TaskRepository(dao)
        val viewModel: TaskViewModel = viewModel(factory = TaskViewModelFactory(repository))
        val navController = rememberNavController()

        // 2. Material3 Theme and Navigation
        MaterialTheme(
            colorScheme = lightColorScheme()
        ) {
            NavGraph(navController = navController, viewModel = viewModel)
        }
    }
}