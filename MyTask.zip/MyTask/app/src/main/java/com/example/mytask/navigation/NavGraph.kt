package com.example.mytask.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.mytask.screens.AddEditTaskScreen
import com.example.mytask.screens.HomeScreen
import com.example.mytask.viewmodel.TaskViewModel

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object AddEdit : Screen("add_edit")
}

@Composable
fun NavGraph(navController: NavHostController, viewModel: TaskViewModel) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(navController, viewModel)
        }
        composable(Screen.AddEdit.route) {
            AddEditTaskScreen(navController, viewModel)
        }
    }
}
